-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 26, 2015 at 11:47 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_test`
--
CREATE DATABASE IF NOT EXISTS `library_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library_test`;

-- --------------------------------------------------------

--
-- Table structure for table `authors_books_t`
--

CREATE TABLE IF NOT EXISTS `authors_books_t` (
  `id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors_books_t`
--

INSERT INTO `authors_books_t` (`id`, `author_id`, `book_id`) VALUES
(1, 9, 1),
(2, 10, 2),
(3, 10, 3),
(4, 11, 12),
(5, 12, 13),
(6, 13, 13),
(7, 22, 14),
(8, 23, 15),
(9, 23, 16),
(10, 24, 25),
(11, 25, 26),
(12, 26, 26),
(13, 35, 27),
(14, 36, 28),
(15, 36, 29),
(16, 37, 38),
(17, 38, 39),
(18, 39, 39),
(19, 48, 40),
(20, 49, 41),
(21, 49, 42),
(22, 50, 51),
(23, 51, 52),
(24, 52, 52),
(25, 61, 53),
(26, 62, 54),
(27, 62, 55),
(28, 63, 64),
(29, 64, 65),
(30, 65, 65),
(31, 74, 66),
(32, 75, 67),
(33, 75, 68),
(34, 76, 77),
(35, 77, 78),
(36, 78, 78),
(37, 87, 79),
(38, 88, 80),
(39, 88, 81),
(40, 89, 90),
(41, 90, 91),
(42, 91, 91),
(43, 100, 92),
(44, 101, 93),
(45, 101, 94),
(46, 102, 103),
(47, 103, 104),
(48, 104, 104),
(49, 113, 105),
(50, 114, 106),
(51, 114, 107),
(52, 115, 116),
(53, 116, 117),
(54, 117, 117),
(55, 126, 118),
(56, 127, 119),
(57, 127, 120),
(58, 128, 129),
(59, 129, 130),
(60, 130, 130),
(61, 139, 131),
(62, 140, 132),
(63, 140, 133),
(64, 141, 142),
(65, 142, 143),
(66, 143, 143),
(67, 152, 145),
(68, 153, 146),
(69, 153, 147),
(70, 154, 156),
(71, 155, 157),
(72, 156, 157),
(73, 165, 159),
(74, 166, 160),
(75, 166, 161),
(76, 167, 170),
(77, 168, 171),
(78, 169, 171),
(79, 178, 173),
(80, 179, 174),
(81, 179, 175),
(82, 180, 184),
(83, 181, 185),
(84, 182, 185),
(85, 191, 187),
(86, 192, 188),
(87, 192, 189),
(88, 193, 198),
(89, 194, 199),
(90, 195, 199),
(91, 204, 201),
(92, 205, 202),
(93, 205, 203),
(94, 206, 212),
(95, 207, 213),
(96, 208, 213),
(97, 217, 215),
(98, 218, 216),
(99, 218, 217),
(100, 219, 226),
(101, 220, 227),
(102, 221, 227),
(103, 230, 229),
(104, 231, 230),
(105, 231, 231),
(106, 232, 240),
(107, 233, 241),
(108, 234, 241),
(109, 243, 243),
(110, 244, 244),
(111, 244, 245),
(112, 245, 254),
(113, 246, 255),
(114, 247, 255),
(115, 256, 257),
(116, 257, 258),
(117, 257, 259),
(118, 258, 268),
(119, 259, 269),
(120, 260, 269),
(121, 269, 271),
(122, 270, 272),
(123, 270, 273),
(124, 271, 282),
(125, 272, 283),
(126, 273, 283),
(127, 282, 285),
(128, 283, 286),
(129, 283, 287),
(130, 284, 296),
(131, 285, 297),
(132, 286, 297),
(133, 295, 299),
(134, 296, 300),
(135, 296, 301),
(136, 297, 310),
(137, 298, 311),
(138, 299, 311),
(139, 308, 313),
(140, 309, 314),
(141, 309, 315),
(142, 310, 324),
(143, 311, 325),
(144, 312, 325),
(145, 321, 327),
(146, 322, 328),
(147, 322, 329),
(148, 323, 338),
(149, 324, 339),
(150, 325, 339);

-- --------------------------------------------------------

--
-- Table structure for table `authors_t`
--

CREATE TABLE IF NOT EXISTS `authors_t` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=326 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `books_t`
--

CREATE TABLE IF NOT EXISTS `books_t` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=341 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `checkouts_t`
--

CREATE TABLE IF NOT EXISTS `checkouts_t` (
  `id` int(11) NOT NULL,
  `copy_id` int(11) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `checked_out` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `copies_t`
--

CREATE TABLE IF NOT EXISTS `copies_t` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `patrons_t`
--

CREATE TABLE IF NOT EXISTS `patrons_t` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors_books_t`
--
ALTER TABLE `authors_books_t`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `authors_t`
--
ALTER TABLE `authors_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books_t`
--
ALTER TABLE `books_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkouts_t`
--
ALTER TABLE `checkouts_t`
  ADD PRIMARY KEY (`id`),
  ADD KEY `copy_id` (`copy_id`),
  ADD KEY `patron_id` (`patron_id`);

--
-- Indexes for table `copies_t`
--
ALTER TABLE `copies_t`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `patrons_t`
--
ALTER TABLE `patrons_t`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors_books_t`
--
ALTER TABLE `authors_books_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=151;
--
-- AUTO_INCREMENT for table `authors_t`
--
ALTER TABLE `authors_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=326;
--
-- AUTO_INCREMENT for table `books_t`
--
ALTER TABLE `books_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=341;
--
-- AUTO_INCREMENT for table `checkouts_t`
--
ALTER TABLE `checkouts_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `copies_t`
--
ALTER TABLE `copies_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=136;
--
-- AUTO_INCREMENT for table `patrons_t`
--
ALTER TABLE `patrons_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
